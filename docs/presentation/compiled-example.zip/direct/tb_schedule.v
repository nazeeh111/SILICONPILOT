`timescale 1ns/1ps
module tb;
  localparam N=78, RUN=12, NI=4, NO=2, W=8;
  reg clk=0; always #5 clk=!clk;
  reg rst=1, in_valid=0;
  reg [NI*W-1:0] in_data=0;
  wire in_ready, out_valid;
  wire [NO*W-1:0] out_data;
  siliconpilot_core dut(.clk(clk),.rst(rst),.in_data(in_data),.in_valid(in_valid),
    .in_ready(in_ready),.out_data(out_data),.out_valid(out_valid),.out_ready(1'b1));
  reg [NI*W-1:0] input_vectors[0:N-1];
  reg [NO*W-1:0] expected[0:N-1];
  integer sent=0, received=0, cycles=0, first_sent=-1, previous_output=-1;
  integer measured_latency=-1, measured_interval=-1;
  initial begin
    $readmemh("inputs.hex",input_vectors);
    $readmemh("expected.hex",expected);
    repeat(3) @(negedge clk);
    rst=0;
  end
  always @(negedge clk) begin
    if (!rst) begin
      in_valid = sent < RUN;
      if (sent < RUN) in_data = input_vectors[sent];
    end
  end
  always @(posedge clk) begin
    if (!rst) begin
      cycles=cycles+1;
      if (in_valid && in_ready) begin
        if (sent==0) first_sent=cycles;
        sent=sent+1;
      end
      if (out_valid) begin
        if (received>=sent || out_data !== expected[received])
          $fatal(1,"SCHEDULE_DATA_MISMATCH sample=%0d got=%h",received,out_data);
        if (received==0) begin
          measured_latency=cycles-first_sent-1;
          if (measured_latency!=49)
            $fatal(1,"SCHEDULE_LATENCY got=%0d expected=49",measured_latency);
        end else begin
          measured_interval=cycles-previous_output;
          if (measured_interval!=34)
            $fatal(1,"SCHEDULE_INTERVAL got=%0d expected=34",measured_interval);
        end
        previous_output=cycles;
        received=received+1;
      end
      if (received==RUN && cycles-previous_output>83) begin
        $display("SCHEDULE_PASS samples=%0d latency=%0d interval=%0d",received,measured_latency,measured_interval);
        $finish;
      end
      if (cycles>1044) $fatal(1,"SCHEDULE_TIMEOUT");
    end
  end
endmodule
