SiliconPilot generated verification bundle

Source: https://github.com/nazeeh111/SILICONPILOT/tree/6e2bbbe2faca1f10eb4a2a1e71a8aa858c56ffd1
Recorded 2026-11-17. No tool executables are bundled.

With Icarus Verilog/vvp installed, cd direct or overlapped, then:
iverilog -g2012 -s tb -o reopened-sim design.v tb_core.v
vvp reopened-sim

The checker compares all 78 synthetic/boundary inputs against retained expected vectors. This is RTL simulation, not a physical hardware measurement.

Generated weights retain the original model/data provenance. See THIRD_PARTY.md for Volker Lohweg, UCI Banknote Authentication (2012), DOI10.24432/C55P57, CC BY4.0. Original compiler source is Apache2.0; see LICENSE. External tools keep their own licenses and are not included.
